import requests
import re
from dataclasses import dataclass
from typing import Optional, Tuple
from ..prompts.prompt_definitions import carregar_prompt_custom

class GeminiAPIClient:
    """Cliente para interação com a API Gemini"""

    def __init__(self, api_key: str):
        self.api_url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key={api_key}"
        self.headers = {
            "Content-Type": "application/json"
        }

    def make_request(self, prompt: str, timeout: int = 10) -> Tuple[Optional[dict], Optional[str]]:
        payload = {
            "contents": [
                {"parts": [{"text": prompt}]}
            ]
        }
        try:
            response = requests.post(
                self.api_url,
                headers=self.headers,
                json=payload,
                timeout=timeout
            )
            if response.status_code == 200:
                return response.json(), None
            return None, f"HTTP {response.status_code}: {response.text}"
        except Exception as e:
            return None, str(e)

@dataclass
class ClassificationResult:
    classification: str
    status: str
    method: str
    confidence: float = 1.0

class GeminiLegalClassifier:
    """Implementação específica para Gemini"""

    def __init__(self, api_key: str):
        self.api_client = GeminiAPIClient(api_key)
        self.classifier_type = "gemini-pro"
        self.system_prompt = carregar_prompt_custom()

    def _local_classification(self, text: str) -> ClassificationResult:
        text_lower = text.lower()

        if (re.search(r'tipo\s*de\s*comunicacao\s*:\s*citacao', text_lower) and
                re.search(r'\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}', text)):
            return ClassificationResult("citação", "sucesso", "regras_locais", 0.9)

        if (re.search(r"(intime-se as autoridades coatoras|intimem-se os impetrados)", text_lower) and
                re.search(r"(prestem|prestar|apresentem|apresentar) (informações|esclarecimentos)", text_lower) and
                re.search(r"(no prazo de|em) (dez|\d+) dias", text_lower)):
            return ClassificationResult("citação", "sucesso", "regras_locais")

        if re.search(r"intime-se", text_lower):
            return ClassificationResult("intimação", "sucesso", "regras_locais")

        return ClassificationResult("fora_de_contexto", "sucesso", "regras_locais")

    def classify_text(self, text: str) -> ClassificationResult:
        local_result = self._local_classification(text)
        if local_result.method == "regras_locais":
            return local_result

        full_prompt = f"{self.system_prompt}\nTexto:\n{text}"

        api_response, error = self.api_client.make_request(full_prompt)

        if error:
            return local_result

        try:
            result = api_response['candidates'][0]['content']['parts'][0]['text'].strip().lower()
            if result in ("citação", "intimação", "fora_de_contexto"):
                return ClassificationResult(result, "sucesso", "ia_gemini-pro")
        except (KeyError, IndexError, AttributeError):
            pass

        return local_result


def create_classifier(api_key: str) -> GeminiLegalClassifier:
    """Factory para criação do classificador Gemini"""
    return GeminiLegalClassifier(api_key)
