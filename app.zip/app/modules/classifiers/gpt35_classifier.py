import re
from dataclasses import dataclass
from typing import Optional, Tuple
from ..prompts.prompt_definitions import carregar_prompt_custom


class GPT35APIClient:
    """Cliente para interação com a API GPT35"""

    def __init__(self, api_key: str):
        self.api_url = "https://api.gpt-3.5-turbo.com/v1/chat/completions"
        self.headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }

    def make_request(self, payload: dict, timeout: int = 10) -> Tuple[Optional[dict], Optional[str]]:
        """Faz uma requisição à API com tratamento de erros"""
        try:
            response = requests.post(
                self.api_url,
                headers=self.headers,
                json=payload,
                timeout=timeout
            )
            if response.status_code == 200:
                return response.json(), None
            return None, f"HTTP {response.status_code}: {response.text}"
        except Exception as e:
            return None, str(e)

@dataclass
class ClassificationResult:
    """Estrutura para resultados de classificação"""
    classification: str  # "citação", "intimação" ou "fora_de_contexto"
    status: str  # "sucesso" ou mensagem de erro
    method: str  # "regras_locais", "ia_gpt-3.5-turbo", "fallback_local"
    confidence: float = 1.0  # Add this new field with default value


class GPT35LegalClassifier:
    """Implementação específica para GPT35"""

    def __init__(self, api_key: str):
        super().__init__()
        self.api_client = GPT35APIClient(api_key)
        self.classifier_type = "gpt-3.5-turbo"
        self.system_prompt = carregar_prompt_custom()

    def _local_classification(self, text: str) -> ClassificationResult:
        """Classificação com regras aprimoradas"""
        text_lower = text.lower()

        # 1. Verifica citação explícita com número de processo
        if (re.search(r'tipo\s*de\s*comunicacao\s*:\s*citacao', text_lower) and
                re.search(r'\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}', text)):
            return ClassificationResult("citação", "sucesso", "regras_locais", 0.9)

        # 2. Padrões existentes de mandado de segurança...

        # Padrão completo para Mandado de Segurança
        if (re.search(r"(intime-se as autoridades coatoras|intimem-se os impetrados)", text_lower) and
                re.search(r"(prestem|prestar|apresentem|apresentar) (informações|esclarecimentos)", text_lower) and
                re.search(r"(no prazo de|em) (dez|\d+) dias", text_lower)):
            return ClassificationResult("citação", "sucesso", "regras_locais")

        # Padrão genérico para intimações
        if re.search(r"intime-se", text_lower):
            return ClassificationResult("intimação", "sucesso", "regras_locais")

        return ClassificationResult("fora_de_contexto", "sucesso", "regras_locais")

    def classify_text(self, text: str) -> ClassificationResult:
        """Versão simplificada com fallback absoluto"""
        try:
            # 1. Tenta classificação local
            local_result = self._local_classification(text)
            if local_result.method == "regras_locais":
                return local_result

            # 2. Fallback seguro se houver qualquer erro
            return ClassificationResult("intimação", "aviso: fallback_secure", "fallback_local")

        except Exception:
            return ClassificationResult("intimação", "aviso: error_handled", "fallback_local")

    def classify_text(self, text: str) -> ClassificationResult:
        """Classifica o texto com fallback seguro"""
        # 1ª Camada: Regras Locais
        local_result = self._local_classification(text)
        if local_result.method == "regras_locais":
            return local_result

        # 2ª Camada: API GPT35
        payload = {
            "model": "gpt-3.5-turbo-chat",
            "messages": [
                {"role": "system", "content": self.system_prompt},
                {"role": "user", "content": text}
            ],
            "temperature": 0.0,
            "max_tokens": 10
        }

        api_response, error = self.api_client.make_request(payload)

        if error:
            return local_result  # Retorna fallback local se a API falhar

        try:
            result = api_response['choices'][0]['message']['content'].strip().lower()
            if result in ("citação", "intimação", "fora_de_contexto"):
                return ClassificationResult(result, "sucesso", "ia_gpt-3.5-turbo")
        except (KeyError, AttributeError):
            pass

        return local_result


def test_classifier(api_key: str):
    """Função de teste que seu notebook espera"""
    classifier = GPT35LegalClassifier(api_key)

    test_cases = [
        ("Intime-se a autoridade coatora para prestar informações em 10 dias", "citação"),
        ("Cite-se o réu para apresentar defesa em 15 dias", "citação"),
        ("Intime-se o MP para manifestação em 5 dias", "intimação"),
        ("Workshop sobre jurisprudência", "fora_de_contexto")
    ]

    print("🔬 Teste do Classificador Jurídico")
    print("=" * 60)
    for text, expected in test_cases:
        result = classifier.classify_text(text)
        emoji = "✅" if result.classification == expected else "❌"
        print(f"\n{emoji} Texto: {text[:50]}...")
        print(f"Classificação: {result.classification} (Esperado: {expected})")
        print(f"Método: {result.method} | Status: {result.status}")
    print("\n" + "=" * 60)


# Interface opcional para notebooks
class APITester:
    """Painel interativo para teste da API"""

    def __init__(self):
        self.api_key_input = widgets.Password(description="API Key:")
        self.test_button = widgets.Button(description="Testar API", button_style='success')
        self.output = widgets.Output()

        self.test_button.on_click(self._run_tests)

    def _run_tests(self, b):
        with self.output:
            self.output.clear_output()
            if not self.api_key_input.value:
                print("⚠️ Por favor, insira uma API Key válida")
                return
            test_classifier(self.api_key_input.value)

    def show(self):
        """Exibe a interface"""
        display(widgets.VBox([
            widgets.HTML("<h3>🔧 Painel de Teste da API</h3>"),
            self.api_key_input,
            self.test_button,
            self.output
        ]))


# Para uso direto via importação
def create_classifier(api_key: str) -> GPT35LegalClassifier:
    """Factory para criação do classificador"""
    return GPT35LegalClassifier(api_key)


import ipywidgets as widgets
from IPython.display import display, clear_output
import requests


class GPT35APITester:
    def __init__(self):
        self.api_key_input = widgets.Password(
            description="API Key:",
            layout={'width': '400px'},
            style={'description_width': '100px'}
        )
        self.test_button = widgets.Button(
            description="Testar Conexão API",
            button_style='info',
            icon='plug'
        )
        self.result_output = widgets.Output()
        self.status_indicator = widgets.HTML()

        self.test_button.on_click(self._test_api_connection)

    def _test_api_connection(self, b):
        with self.result_output:
            clear_output()
            api_key = self.api_key_input.value.strip()

            if not api_key:
                self.status_indicator.value = """<div style="color: white; background-color: #f0ad4e; 
                                              padding: 10px; border-radius: 5px;">
                                              ⚠️ Insira uma chave API válida</div>"""
                return

            headers = {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json"
            }

            payload = {
                "model": "gpt-3.5-turbo-chat",
                "messages": [{"role": "user", "content": "Teste de conexão"}],
                "max_tokens": 1,
                "temperature": 0
            }

            try:
                response = requests.post(
                    "https://api.gpt-3.5-turbo.com/v1/chat/completions",
                    headers=headers,
                    json=payload,
                    timeout=10
                )

                if response.status_code == 200:
                    self.status_indicator.value = """<div style="color: white; background-color: #5cb85c; 
                                                  padding: 10px; border-radius: 5px;">
                                                  ✅ API operacional (Status HTTP 200)</div>"""
                    print("Resposta da API:", response.json())
                else:
                    self.status_indicator.value = f"""<div style="color: white; background-color: #d9534f; 
                                                   padding: 10px; border-radius: 5px;">
                                                   ❌ Falha na API (HTTP {response.status_code})</div>"""
                    print("Erro detalhado:", response.text)

            except Exception as e:
                self.status_indicator.value = f"""<div style="color: white; background-color: #d9534f; 
                                               padding: 10px; border-radius: 5px;">
                                               ❌ Erro de conexão: {str(e)}</div>"""

    def show(self):
        """Exibe a interface de teste"""
        display(widgets.VBox([
            widgets.HTML("<h3 style='margin-bottom: 20px'>🔌 Teste de Conexão API GPT35</h3>"),
            widgets.HBox([self.api_key_input, self.test_button]),
            self.status_indicator,
            self.result_output
        ]))



# Exemplo de uso
if __name__ == "__main__":
    # Teste manual (opcional)
    classifier = create_classifier("sua_chave_aqui")
    resultado = classifier.classify_text("Intime-se a autoridade coatora...")
    print(f"Resultado: {resultado}")