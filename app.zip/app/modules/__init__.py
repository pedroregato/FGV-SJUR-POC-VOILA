# modules/__init__.py
# modules/__init__.py
from .classifiers.deepseek_classifier import DeepSeekLegalClassifier
from .classifiers.gpt35_classifier import GPT35LegalClassifier
from .classifiers.gemini_classifier import GeminiLegalClassifier
from .classifiers.regex_classifier import RegexLegalClassifier, RegexClassificationResult
from .utilitarios import inicializar_base_avaliacoes, registrar_avaliacao
from .search_tokens import (
    highlight_text,
    count_occurrences,
    extrair_metadados,
    ExtractedDeadline,
    ParteReu,
    extract_partes_reus
)

__all__ = [
    'DeepSeekLegalClassifier',
    'GPT35LegalClassifier',
    'RegexLegalClassifier',
    'GeminiLegalClassifier',
    'RegexClassificationResult',
    'inicializar_base_avaliacoes',
    'registrar_avaliacao',
    'highlight_text',
    'count_occurrences',
    'extrair_metadados',
    'ExtractedDeadline',
    'ParteReu',
    'extract_partes_reus'
]